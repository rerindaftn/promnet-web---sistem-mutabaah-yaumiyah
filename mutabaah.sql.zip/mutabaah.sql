-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2021 at 07:29 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mutabaah`
--

-- --------------------------------------------------------

--
-- Table structure for table `access`
--

CREATE TABLE `access` (
  `id` int(11) NOT NULL,
  `appid` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `access`
--

INSERT INTO `access` (`id`, `appid`) VALUES
(1, '111111'),
(2, '222222'),
(3, '333333');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `position`, `name`) VALUES
(7, 'herdy', '$2y$10$cW1Lm7FlC5H0SU9sBRCnA.m', 'Admin', 'Herdy Gumilang Jati'),
(8, 'bahrul', '$2y$10$IjasjTdu/nHNVXhRBRo4S.I', 'Admin', 'Muhammad Bahrul Ulum'),
(9, 'rerinda', '$2y$10$i1dYLR6JnitKhUxrUpUL/uu', 'Admin', 'Rerinda Fiktianti'),
(10, 'salwa', '$2y$10$sbyIpDUmap7zMcogE8w5TO8', 'Admin', 'Salwa Iqlima KVG');

-- --------------------------------------------------------

--
-- Table structure for table `class-1`
--

CREATE TABLE `class-1` (
  `id` int(11) NOT NULL,
  `subject-name` varchar(30) NOT NULL,
  `program1` varchar(30) NOT NULL,
  `program2` varchar(30) NOT NULL,
  `program3` varchar(30) NOT NULL,
  `program4` varchar(30) NOT NULL,
  `program5` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `class-2`
--

CREATE TABLE `class-2` (
  `id` int(11) NOT NULL,
  `subject-name` varchar(30) NOT NULL,
  `program1` varchar(30) NOT NULL,
  `program2` varchar(30) NOT NULL,
  `program3` varchar(30) NOT NULL,
  `program4` varchar(30) NOT NULL,
  `program5` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `class-3`
--

CREATE TABLE `class-3` (
  `id` int(11) NOT NULL,
  `subject-name` varchar(30) NOT NULL,
  `program1` varchar(30) NOT NULL,
  `program2` varchar(30) NOT NULL,
  `program3` varchar(30) NOT NULL,
  `program4` varchar(30) NOT NULL,
  `program5` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `number` varchar(30) NOT NULL,
  `progress` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `guest-todolist`
--

CREATE TABLE `guest-todolist` (
  `username` varchar(30) NOT NULL,
  `program` varchar(30) NOT NULL,
  `checked` varchar(30) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `nis` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `class` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `number` varchar(30) NOT NULL,
  `progress` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student-listwork`
--

CREATE TABLE `student-listwork` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `class` varchar(30) NOT NULL,
  `allchecked` varchar(30) NOT NULL,
  `subject-name` varchar(30) NOT NULL,
  `program1` varchar(30) NOT NULL,
  `checked1` varchar(30) NOT NULL,
  `program2` varchar(30) NOT NULL,
  `checked2` varchar(30) NOT NULL,
  `program3` varchar(30) NOT NULL,
  `checked3` varchar(30) NOT NULL,
  `program4` varchar(30) NOT NULL,
  `checked4` varchar(30) NOT NULL,
  `program5` varchar(30) NOT NULL,
  `checked5` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student-todolist`
--

CREATE TABLE `student-todolist` (
  `username` varchar(30) NOT NULL,
  `program` text NOT NULL,
  `checked` varchar(30) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `number` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `teacher-todolist`
--

CREATE TABLE `teacher-todolist` (
  `username` varchar(30) NOT NULL,
  `program` text NOT NULL,
  `checked` varchar(30) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access`
--
ALTER TABLE `access`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class-1`
--
ALTER TABLE `class-1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class-2`
--
ALTER TABLE `class-2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class-3`
--
ALTER TABLE `class-3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guest-todolist`
--
ALTER TABLE `guest-todolist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student-listwork`
--
ALTER TABLE `student-listwork`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student-todolist`
--
ALTER TABLE `student-todolist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher-todolist`
--
ALTER TABLE `teacher-todolist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access`
--
ALTER TABLE `access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `class-1`
--
ALTER TABLE `class-1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `class-2`
--
ALTER TABLE `class-2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `class-3`
--
ALTER TABLE `class-3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guest`
--
ALTER TABLE `guest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `guest-todolist`
--
ALTER TABLE `guest-todolist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student-listwork`
--
ALTER TABLE `student-listwork`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `student-todolist`
--
ALTER TABLE `student-todolist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `teacher-todolist`
--
ALTER TABLE `teacher-todolist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
